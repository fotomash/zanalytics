cd /Users/tom/Documents/GitHub/zanalytics/dashboard
source /Users/tom/Documents/GitHub/venv2/bin/activate
streamlit run 🏠\ Home.py .py --server.port=80
ngrok start --all
