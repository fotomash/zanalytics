
import pandas as pd
import numpy as np

class VolumeProfileAnalyzer:
    def analyze(self, df, bins=50):
        price_range = np.linspace(df['low'].min(), df['high'].max(), bins)
        volume_at_price = np.zeros(bins)
        
        for _, row in df.iterrows():
            price_bins = np.digitize([row['low'], row['high']], price_range)
            for bin_idx in range(price_bins[0], price_bins[1]):
                if bin_idx < bins:
                    volume_at_price[bin_idx] += row['volume']
        
        profile = pd.DataFrame({'price': price_range, 'volume': volume_at_price})
        poc_index = profile['volume'].idxmax()
        poc = profile.loc[poc_index]
        
        return {'profile': profile, 'poc': poc}
