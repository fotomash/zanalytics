
import pandas as pd
import numpy as np

class MicroAnalyzer:
    def analyze(self, m1_df, ticks_df):
        ticks_with_delta = self._calculate_tick_delta(ticks_df)
        aggregated_df = self._aggregate_ticks_to_bars(m1_df, ticks_with_delta)
        
        return {
            'aggregated_metrics': aggregated_df,
            'cumulative_delta': aggregated_df['delta'].cumsum()
        }

    def _calculate_tick_delta(self, ticks_df):
        ticks = ticks_df.copy()
        price_col = 'last' if 'last' in ticks.columns and ticks['last'].sum() > 0 else 'mid_price'
        if price_col == 'mid_price':
            ticks['mid_price'] = (ticks['bid'] + ticks['ask']) / 2
            
        price_diff = ticks[price_col].diff()
        tick_direction = np.where(price_diff > 0, 1, np.where(price_diff < 0, -1, 0))
        
        volume_col = 'volume' if 'volume' in ticks.columns and ticks['volume'].sum() > 0 else None
        
        if volume_col:
            ticks['delta'] = tick_direction * ticks[volume_col]
        else:
            ticks['delta'] = tick_direction
            
        return ticks

    def _aggregate_ticks_to_bars(self, m1_df, ticks_df):
        if not isinstance(m1_df.index, pd.DatetimeIndex):
            m1_df.index = pd.to_datetime(m1_df.index)
            
        resampler = ticks_df.resample('1Min')
        delta_sum = resampler['delta'].sum()
        
        aggregated_data = pd.DataFrame(index=m1_df.index)
        aggregated_data['delta'] = delta_sum.reindex(m1_df.index, fill_value=0)
        aggregated_data['cumulative_delta'] = aggregated_data['delta'].cumsum()
        
        return aggregated_data
