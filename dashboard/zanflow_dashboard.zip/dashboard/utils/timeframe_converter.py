
import pandas as pd

class TimeframeConverter:
    def generate_all_timeframes(self, m1_df):
        timeframes = {'M1': m1_df}
        ohlc_dict = {'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum'}
        
        tf_map = {'M5': '5T', 'M15': '15T', 'M30': '30T', 'H1': '1H', 'H4': '4H', 'D1': '1D', 'W1': '1W'}
        
        for tf_name, tf_code in tf_map.items():
            try:
                resampled_df = m1_df.resample(tf_code).agg(ohlc_dict).dropna()
                timeframes[tf_name] = resampled_df
            except Exception as e:
                print(f"Could not resample to {tf_name}: {e}")
                
        return timeframes
