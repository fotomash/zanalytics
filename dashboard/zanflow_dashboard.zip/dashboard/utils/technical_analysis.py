
import pandas as pd

class TechnicalAnalysis:
    def calculate_sma(self, df, period=20):
        return df['close'].rolling(window=period).mean()

    def calculate_ema(self, df, period=20):
        return df['close'].ewm(span=period, adjust=False).mean()

    def calculate_rsi(self, df, period=14):
        delta = df['close'].diff()
        gain = (delta.where(delta > 0, 0)).rolling(window=period).mean()
        loss = (-delta.where(delta < 0, 0)).rolling(window=period).mean()
        rs = gain / loss
        return 100 - (100 / (1 + rs))

    def calculate_all(self, df):
        results = {
            'SMA_20': self.calculate_sma(df, 20),
            'EMA_20': self.calculate_ema(df, 20),
            'RSI_14': self.calculate_rsi(df, 14)
        }
        return pd.DataFrame(results)
