
import plotly.graph_objects as go
from plotly.subplots import make_subplots

class ChartBuilder:
    def build_main_chart(self, df, analysis_results):
        fig = make_subplots(rows=2, cols=1, shared_xaxes=True, vertical_spacing=0.05, row_heights=[0.7, 0.3])
        
        # Candlestick chart
        fig.add_trace(go.Candlestick(x=df.index, open=df['open'], high=df['high'], low=df['low'], close=df['close'], name='OHLC'), row=1, col=1)
        
        # Add SMC elements
        if 'smc' in analysis_results:
            smc_res = analysis_results['smc']
            # Order Blocks
            for _, ob in smc_res['order_blocks']['bullish'].iterrows():
                fig.add_shape(type="rect", x0=ob['start_time'], y0=ob['bottom'], x1=df.index[-1], y1=ob['top'], line=dict(color="Green"), fillcolor="rgba(0,255,0,0.2)", row=1, col=1)
            for _, ob in smc_res['order_blocks']['bearish'].iterrows():
                fig.add_shape(type="rect", x0=ob['start_time'], y0=ob['bottom'], x1=df.index[-1], y1=ob['top'], line=dict(color="Red"), fillcolor="rgba(255,0,0,0.2)", row=1, col=1)

        # Add Indicators
        if 'indicators' in analysis_results:
            ind_res = analysis_results['indicators']
            fig.add_trace(go.Scatter(x=ind_res.index, y=ind_res['EMA_20'], name='EMA 20', line=dict(color='yellow', width=1)), row=1, col=1)
            fig.add_trace(go.Scatter(x=ind_res.index, y=ind_res['RSI_14'], name='RSI'), row=2, col=1)

        fig.update_layout(title="Main Chart Analysis", template="plotly_dark", xaxis_rangeslider_visible=False, height=700)
        return fig

    def build_simple_chart(self, df, title):
        fig = go.Figure(data=[go.Candlestick(x=df.index, open=df['open'], high=df['high'], low=df['low'], close=df['close'])])
        fig.update_layout(title=title, template="plotly_dark", xaxis_rangeslider_visible=False, height=400)
        return fig
