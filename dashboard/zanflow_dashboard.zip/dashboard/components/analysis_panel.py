
import streamlit as st
import pandas as pd

class AnalysisPanel:
    def display(self, results):
        st.sidebar.subheader("📊 Analysis Results")
        if not results:
            st.sidebar.info("No analysis has been run.")
            return
            
        if 'volume_profile' in results:
            poc = results['volume_profile']['poc']
            st.sidebar.metric("Point of Control (POC)", f"${poc['price']:.5f}", f"{poc['volume']:.0f} Volume")

        if 'wyckoff' in results and not results['wyckoff']['events'].empty:
            last_event = results['wyckoff']['events'].iloc[-1]
            st.sidebar.metric("Last Wyckoff Event", last_event['event'], last_event['time'].strftime('%Y-%m-%d %H:%M'))

    def display_market_structure(self, smc_results):
        st.subheader("Liquidity Zones")
        col1, col2 = st.columns(2)
        with col1:
            st.write("Buy-side Liquidity (Recent Highs)")
            st.dataframe(smc_results['liquidity_zones']['bsl'].tail(5))
        with col2:
            st.write("Sell-side Liquidity (Recent Lows)")
            st.dataframe(smc_results['liquidity_zones']['ssl'].tail(5))
