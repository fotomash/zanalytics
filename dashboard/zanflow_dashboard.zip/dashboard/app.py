
import streamlit as st
import pandas as pd
import os
from datetime import datetime
import plotly.graph_objects as go   
from plotly.subplots import make_subplots

# Import custom modules
from utils.data_processor import DataProcessor
from utils.timeframe_converter import TimeframeConverter
from utils.technical_analysis import TechnicalAnalysis
from utils.smc_analyzer import SMCAnalyzer
from utils.wyckoff_analyzer import WyckoffAnalyzer
from utils.volume_profile_analyzer import VolumeProfileAnalyzer
from components.chart_builder import ChartBuilder
from components.analysis_panel import AnalysisPanel
from utils.microstructure_analyzer import MicroAnalyzer

# --- Page Configuration ---
st.set_page_config(
    page_title="Zanflow Analytics Dashboard",
    page_icon="📈",
    layout="wide",
    initial_sidebar_state="expanded"
)

# --- Initialize Session State ---
if 'data' not in st.session_state:
    st.session_state.data = None
if 'timeframes' not in st.session_state:
    st.session_state.timeframes = {}
if 'analysis_results' not in st.session_state:
    st.session_state.analysis_results = {}
if 'tick_data' not in st.session_state:
    st.session_state.tick_data = None
if 'microstructure_results' not in st.session_state:
    st.session_state.microstructure_results = None

# --- Main Application ---
def main():
    st.title("📈 Zanflow Analytics Dashboard")
    st.markdown("A comprehensive tool for top-down market analysis, from macro structure to micro order flow.")

    # --- Sidebar for Controls ---
    with st.sidebar:
        st.header("⚙️ Controls")

        # --- Data Selection ---
        st.subheader("📂 Data Selection")
        data_folder = './data'
        if not os.path.exists(data_folder):
            os.makedirs(data_folder)
        
        available_files = [f for f in os.listdir(data_folder) if f.endswith('_bars.csv')]
        if not available_files:
            st.warning("No data files found in the '/data' folder. Please add your CSV files.")
            st.stop()

        selected_file = st.selectbox("Select Data File", available_files)

        # --- Data Loading Logic (placeholder) ---
        if st.button("🔄 Load Data", type="primary"):
            with st.spinner("Loading M1 and Tick data..."):
                try:
                    # --- Load M1 Bar Data ---
                    bar_file_path = os.path.join('./data', selected_file)
                    data_processor = DataProcessor()
                    st.session_state.data = data_processor.load_data(bar_file_path)
                    st.success(f"✅ Loaded {len(st.session_state.data)} M1 bars from {selected_file}")

                    # --- Generate Timeframes ---
                    converter = TimeframeConverter()
                    st.session_state.timeframes = converter.generate_all_timeframes(st.session_state.data)

                    # Set default selected timeframe if not already set
                    if 'selected_timeframe' not in st.session_state:
                        st.session_state.selected_timeframe = 'H1'
                    
                    # --- Find and Load Corresponding Tick Data ---
                    # Assumes tick file is named like 'XRPUSD_ticks.csv' for 'XRPUSD_M1_bars.csv'
                    symbol = os.path.basename(bar_file_path).split('_')[0]
                    tick_filename = f"{symbol}_ticks.csv"
                    tick_file_path = os.path.join('./data', tick_filename)

                    if os.path.exists(tick_file_path):
                        st.session_state.tick_data = data_processor.load_tick_data(tick_file_path)
                        st.success(f"✅ Loaded {len(st.session_state.tick_data)} ticks from {tick_filename}")
                    else:
                        st.session_state.tick_data = None
                        st.warning(f"⚠️ Tick data file not found at {tick_file_path}. Microstructure analysis will be disabled.")

                except Exception as e:
                    st.error(f"Error loading data: {str(e)}")
                    st.exception(e) # Show full traceback in the app for debugging

        if st.session_state.data is not None:
            # --- Analysis Settings ---
            st.subheader("🛠️ Analysis Settings")
            
            timeframe_options = list(st.session_state.timeframes.keys())
            selected_timeframe = st.selectbox(
                "Select Timeframe",
                timeframe_options,
                index=timeframe_options.index(st.session_state.selected_timeframe) if st.session_state.selected_timeframe in timeframe_options else 0
            )
            st.session_state.selected_timeframe = selected_timeframe
            
            st.markdown("**Analysis Modules**")
            show_smc = st.checkbox("Smart Money Concepts (SMC)", value=True)
            show_wyckoff = st.checkbox("Wyckoff Phases", value=True)
            show_volume_profile = st.checkbox("Volume Profile", value=True)
            show_indicators = st.checkbox("Technical Indicators", value=True)

            # --- Analysis Running Logic (placeholder) ---
            if st.button("🔍 Run Analysis", type="primary"):
                with st.spinner("Running comprehensive analysis... This may take a moment."):
                    try:
                        # Get selected timeframe data
                        tf_data = st.session_state.timeframes[st.session_state.selected_timeframe]
                        
                        # Initialize analyzers
                        smc = SMCAnalyzer() if show_smc else None
                        wyckoff = WyckoffAnalyzer() if show_wyckoff else None
                        volume_profile = VolumeProfileAnalyzer() if show_volume_profile else None
                        ta = TechnicalAnalysis() if show_indicators else None
                        micro_analyzer = MicroAnalyzer() if st.session_state.tick_data is not None else None

                        # Run analyses
                        results = {}
                        if smc:
                            results['smc'] = smc.analyze(tf_data)
                        if wyckoff:
                            results['wyckoff'] = wyckoff.analyze(tf_data)
                        if volume_profile:
                            results['volume_profile'] = volume_profile.analyze(tf_data)
                        if ta:
                            results['indicators'] = ta.calculate_all(tf_data)
                        
                        st.session_state.analysis_results = results
                        
                        # Run microstructure analysis
                        if micro_analyzer:
                            st.session_state.microstructure_results = micro_analyzer.analyze(st.session_state.data, st.session_state.tick_data)
                            st.success("✅ Comprehensive analysis complete!")
                        else:
                            st.session_state.microstructure_results = None
                            st.success("✅ Analysis complete (Microstructure skipped).")

                    except Exception as e:
                        st.error(f"Analysis error: {str(e)}")
                        st.exception(e)

    # --- Main Content Area ---
    if st.session_state.data is None:
        st.info("Please load a data file from the sidebar to begin analysis.")
        st.stop()

    # --- Tabs for different views ---
    tab1, tab2, tab3, tab4, tab5 = st.tabs(["📊 Chart Analysis", "🔬 Microstructure", "🔄 Multi-Timeframe", "📈 Market Structure", "📋 Reports"])

    with tab1:
        st.header(f"📊 Chart Analysis: {st.session_state.selected_timeframe}")
        if st.session_state.analysis_results:
            chart_builder = ChartBuilder()
            analysis_panel = AnalysisPanel()

            main_chart = chart_builder.build_main_chart(
                st.session_state.timeframes[st.session_state.selected_timeframe],
                st.session_state.analysis_results
            )
            st.plotly_chart(main_chart, use_container_width=True)
            
            analysis_panel.display(st.session_state.analysis_results)
        else:
            st.info("Run analysis from the sidebar to view results.")

    # --- Microstructure Tab (placeholder) ---
    with tab2:
        st.header("🔬 Microstructure & Order Flow Analysis")
        if st.session_state.microstructure_results:
            micro_results = st.session_state.microstructure_results['aggregated_metrics']
            
            # Create a chart with 2 y-axes
            fig = make_subplots(specs=[[{"secondary_y": True}]])

            # Add Cumulative Delta
            fig.add_trace(
                go.Scatter(
                    x=micro_results.index, 
                    y=micro_results['cumulative_delta'], 
                    name='Cumulative Delta',
                    line=dict(color='#2196f3', width=2)
                ),
                secondary_y=False,
            )

            # Add Delta per bar
            colors = ['#26a69a' if v >= 0 else '#ef5350' for v in micro_results['delta']]
            fig.add_trace(
                go.Bar(
                    x=micro_results.index, 
                    y=micro_results['delta'], 
                    name='Delta (per bar)',
                    marker_color=colors,
                    opacity=0.6
                ),
                secondary_y=True,
            )

            # Set titles and layout
            fig.update_layout(
                title_text="Cumulative Delta vs. Per-Bar Delta",
                template="plotly_dark",
                height=500,
                legend=dict(yanchor="top", y=0.99, xanchor="left", x=0.01)
            )
            fig.update_yaxes(title_text="<b>Cumulative Delta</b>", secondary_y=False)
            fig.update_yaxes(title_text="<b>Per-Bar Delta</b>", secondary_y=True)
            
            st.plotly_chart(fig, use_container_width=True)
            
            # Display raw metrics
            st.subheader("Microstructure Metrics")
            st.dataframe(micro_results.tail(10))

        else:
            st.info("No tick data loaded. Microstructure analysis is unavailable.")

    with tab3:
        st.header("🔄 Multi-Timeframe Analysis")
        chart_builder = ChartBuilder()
        cols = st.columns(2)
        with cols[0]:
            st.plotly_chart(chart_builder.build_simple_chart(st.session_state.timeframes['D1'], "D1"), use_container_width=True)
            st.plotly_chart(chart_builder.build_simple_chart(st.session_state.timeframes['H1'], "H1"), use_container_width=True)
        with cols[1]:
            st.plotly_chart(chart_builder.build_simple_chart(st.session_state.timeframes['H4'], "H4"), use_container_width=True)
            st.plotly_chart(chart_builder.build_simple_chart(st.session_state.timeframes['M15'], "M15"), use_container_width=True)

    with tab4:
        st.header("📈 Market Structure Overview")
        if st.session_state.analysis_results.get('smc'):
            analysis_panel = AnalysisPanel()
            analysis_panel.display_market_structure(st.session_state.analysis_results['smc'])
        else:
            st.info("Run SMC analysis to view market structure.")

    with tab5:
        st.header("📋 Reports")
        st.info("Reporting features coming soon.")

if __name__ == "__main__":
    main()
